<div class="modal hide fade" id="dialog-metode">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3>Block Replacement Method</h3>
		</div>
		<div class="modal-body">
		
		</div>
		<div class="modal-footer">
			<button class="btn btn-danger" data-dismiss="modal" aria-hidden="true">close</button>
		</div>
	</div>

                     <!-- End Modals-->


<div class="modal hide fade" id="dialog-engine">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3> Detail</h3>
		</div>
		<div class="modal-body">
			
		</div>
		<div class="modal-footer">
			<button class="btn btn-danger" data-dismiss="modal" aria-hidden="true">cancel</button>
		</div>
	</div>
                     <!-- End Modals-->